# Breast Cancer Diagnosis — ML Pipeline + REST API

[![CI](https://github.com/marwan104/breast-cancer-ml-api/actions/workflows/ci.yml/badge.svg)](https://github.com/marwan104/breast-cancer-ml-api/actions/workflows/ci.yml)

An end-to-end machine-learning project: exploratory data analysis, model comparison with cross-validation,
evaluation on a held-out test set, model explainability, and a **FastAPI** service that serves predictions —
with automated tests, Docker and GitHub Actions CI.

> ⚠️ Educational project. It is **not** a medical device and must not be used for real diagnosis.

## Results

Dataset: [Wisconsin Diagnostic Breast Cancer](https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic)
(569 samples, 30 numeric features computed from cell-nucleus images; 212 malignant, 357 benign; no missing values).
Ships with scikit-learn, so no download is needed.

**Model comparison** — 5-fold stratified cross-validation on the training set (80%):

| Model | ROC-AUC | Recall (malignant) | Accuracy | F1 |
|---|---|---|---|---|
| **Logistic Regression** | **0.996 ± 0.005** | 0.953 | 0.974 | 0.964 |
| SVM (RBF, calibrated) | 0.995 ± 0.005 | 0.959 | 0.976 | 0.967 |
| Random Forest | 0.988 ± 0.007 | 0.935 | 0.960 | 0.946 |

**Held-out test set** (114 samples, evaluated once) — Logistic Regression:

| Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|
| 0.965 | 0.975 | 0.929 | 0.951 | 0.996 |

Confusion matrix: 39 of 42 malignant cases caught (3 missed), 1 false alarm out of 72 benign cases.

| | |
|---|---|
| ![Confusion matrix](reports/figures/confusion_matrix.png) | ![ROC curve](reports/figures/roc_curve.png) |
| ![Feature importance](reports/figures/feature_importance.png) | ![Correlations](reports/figures/top_correlations.png) |

Full numbers: [`reports/metrics.json`](reports/metrics.json).

## How it works

1. **Data** (`src/bcd/data.py`) — loads the dataset, relabels so `1 = malignant` (the class we want to catch),
   and makes a stratified 80/20 train/test split.
2. **EDA** (`src/bcd/eda.py`) — class balance and the features most correlated with a malignant diagnosis.
3. **Training** (`src/bcd/train.py`) — each model is a `Pipeline(StandardScaler → classifier)`, so scaling is learned
   inside each CV fold (no data leakage). The best model by mean ROC-AUC is refit on the full training set,
   evaluated once on the test set, explained with permutation importance, and saved with `joblib`.
4. **API** (`api/main.py`) — FastAPI service with request validation (Pydantic): all 30 features required,
   non-negative, no extra fields.
5. **Tests** (`tests/`) — 9 pytest tests for the data, the model's minimum quality and every API endpoint.

## Run it

```bash
git clone https://github.com/marwan104/breast-cancer-ml-api.git
cd breast-cancer-ml-api
python -m venv .venv
# Windows: .venv\Scripts\activate     macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt

# Windows PowerShell: $env:PYTHONPATH="src"     macOS/Linux: export PYTHONPATH=src
python -m bcd.eda        # figures + summary
python -m bcd.train      # trains, compares, saves models/model.joblib + reports/metrics.json
pytest -q                # 9 tests
uvicorn api.main:app --reload
```

Open **http://127.0.0.1:8000/docs** for the interactive Swagger UI.

### Docker

```bash
docker build -t breast-cancer-api .
docker run -p 8000:8000 breast-cancer-api
```

## API

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Service status and whether the model is loaded |
| GET | `/model-info` | Model name, feature list and saved metrics |
| POST | `/predict` | One sample (30 features) → diagnosis + malignant probability |
| POST | `/predict/batch` | Up to 100 samples |

```bash
curl -X POST http://127.0.0.1:8000/predict \
  -H "Content-Type: application/json" \
  -d @examples/sample_request.json
# {"diagnosis":"malignant","malignant_probability":1.0}
```

## Tech stack

Python · scikit-learn · pandas · NumPy · Matplotlib · FastAPI · Pydantic · pytest · Docker · GitHub Actions

## Possible next steps

- Tune the decision threshold to trade a few false alarms for higher recall on malignant cases.
- Add SHAP explanations per prediction.
- Deploy the container (Render / Railway) and add the live link here.

## License

MIT
