"""Exploratory data analysis: class balance, summary stats and correlations.

Run:  python -m bcd.eda   (from the src/ folder, or with PYTHONPATH=src)
Saves figures to reports/figures/ and prints a short summary.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # no screen needed
import matplotlib.pyplot as plt

from bcd.data import load_dataset

ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "reports" / "figures"


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    X, y = load_dataset()

    print(f"Samples: {len(X)}  |  Features: {X.shape[1]}  |  Missing values: {int(X.isna().sum().sum())}")
    counts = y.value_counts().rename({1: "malignant", 0: "benign"})
    print("Class balance:\n" + counts.to_string())

    # 1) Class balance bar chart
    fig, ax = plt.subplots(figsize=(4, 3))
    counts.plot.bar(ax=ax, color=["#4C72B0", "#DD8452"])
    ax.set_title("Class balance")
    ax.set_ylabel("Samples")
    ax.tick_params(axis="x", rotation=0)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "class_balance.png", dpi=120)
    plt.close(fig)

    # 2) Which features move most with the diagnosis?
    corr = X.assign(malignant=y).corr()["malignant"].drop("malignant").sort_values()
    top = corr.abs().sort_values(ascending=False).head(10)
    print("\nTop 10 features by |correlation| with malignant:\n" + top.round(3).to_string())

    fig, ax = plt.subplots(figsize=(6, 4))
    corr[top.index].sort_values().plot.barh(ax=ax, color="#55A868")
    ax.set_title("Correlation with malignant (top 10)")
    ax.set_xlabel("Pearson correlation")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "top_correlations.png", dpi=120)
    plt.close(fig)


if __name__ == "__main__":
    main()
