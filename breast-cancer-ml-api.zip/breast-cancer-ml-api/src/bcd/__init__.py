"""Breast cancer diagnosis: ML pipeline + REST API (educational project)."""

__version__ = "1.0.0"
