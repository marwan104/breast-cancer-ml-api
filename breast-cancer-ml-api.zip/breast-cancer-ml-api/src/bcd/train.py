"""Train, compare and evaluate models, then save the best one.

Run:  python -m bcd.train   (with PYTHONPATH=src)

Steps
1. Split data 80/20 (stratified).
2. Compare 3 models with 5-fold stratified cross-validation on the TRAIN set only.
   Every model is a Pipeline (StandardScaler + classifier) so scaling is learned
   inside each fold -> no data leakage.
3. Pick the model with the best mean ROC-AUC.
4. Fit it on the full train set, evaluate ONCE on the held-out test set.
5. Save the model (models/model.joblib), metrics (reports/metrics.json) and figures.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from bcd.data import FEATURE_NAMES, RANDOM_STATE, load_dataset, split

ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = ROOT / "models" / "model.joblib"
METRICS_PATH = ROOT / "reports" / "metrics.json"
FIG_DIR = ROOT / "reports" / "figures"


def candidate_models() -> dict[str, Pipeline]:
    return {
        "logistic_regression": Pipeline(
            [("scale", StandardScaler()), ("clf", LogisticRegression(max_iter=5000, random_state=RANDOM_STATE))]
        ),
        "random_forest": Pipeline(
            [("scale", StandardScaler()), ("clf", RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE))]
        ),
        "svm_rbf": Pipeline(
            [("scale", StandardScaler()), ("clf", CalibratedClassifierCV(SVC(kernel="rbf", random_state=RANDOM_STATE), ensemble=False))]
        ),
    }


def compare_models(X_train: pd.DataFrame, y_train: pd.Series) -> pd.DataFrame:
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    rows = []
    for name, model in candidate_models().items():
        scores = cross_validate(model, X_train, y_train, cv=cv, scoring=["roc_auc", "recall", "accuracy", "f1"])
        rows.append(
            {
                "model": name,
                "cv_roc_auc": scores["test_roc_auc"].mean(),
                "cv_roc_auc_std": scores["test_roc_auc"].std(),
                "cv_recall": scores["test_recall"].mean(),
                "cv_accuracy": scores["test_accuracy"].mean(),
                "cv_f1": scores["test_f1"].mean(),
            }
        )
    return pd.DataFrame(rows).sort_values("cv_roc_auc", ascending=False).reset_index(drop=True)


def evaluate(model: Pipeline, X_test: pd.DataFrame, y_test: pd.Series) -> dict:
    proba = model.predict_proba(X_test)[:, 1]
    pred = (proba >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, pred).ravel()
    return {
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred),
        "recall": recall_score(y_test, pred),  # share of malignant cases we caught
        "f1": f1_score(y_test, pred),
        "roc_auc": roc_auc_score(y_test, proba),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "test_samples": int(len(y_test)),
    }


def save_figures(model: Pipeline, X_test: pd.DataFrame, y_test: pd.Series) -> list[dict]:
    FIG_DIR.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(4, 4))
    ConfusionMatrixDisplay.from_estimator(model, X_test, y_test, display_labels=["benign", "malignant"], ax=ax, colorbar=False)
    ax.set_title("Confusion matrix (test set)")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "confusion_matrix.png", dpi=120)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(4, 4))
    RocCurveDisplay.from_estimator(model, X_test, y_test, ax=ax)
    ax.set_title("ROC curve (test set)")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "roc_curve.png", dpi=120)
    plt.close(fig)

    # Permutation importance: how much does ROC-AUC drop when we shuffle one feature?
    imp = permutation_importance(model, X_test, y_test, scoring="roc_auc", n_repeats=20, random_state=RANDOM_STATE)
    importance = (
        pd.DataFrame({"feature": FEATURE_NAMES, "importance": imp.importances_mean})
        .sort_values("importance", ascending=False)
        .head(10)
    )
    fig, ax = plt.subplots(figsize=(6, 4))
    importance.sort_values("importance").plot.barh(x="feature", y="importance", ax=ax, legend=False, color="#C44E52")
    ax.set_title("Top 10 features (permutation importance)")
    ax.set_xlabel("Mean drop in ROC-AUC")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "feature_importance.png", dpi=120)
    plt.close(fig)
    return importance.round(4).to_dict(orient="records")


def main() -> None:
    X, y = load_dataset()
    X_train, X_test, y_train, y_test = split(X, y)

    comparison = compare_models(X_train, y_train)
    print("Cross-validation on train set (5 folds):")
    print(comparison.round(4).to_string(index=False))

    best_name = comparison.loc[0, "model"]
    best = candidate_models()[best_name].fit(X_train, y_train)
    test_metrics = evaluate(best, X_test, y_test)
    top_features = save_figures(best, X_test, y_test)

    print(f"\nBest model: {best_name}")
    print("Test set: " + ", ".join(f"{k}={v:.4f}" for k, v in test_metrics.items() if isinstance(v, float)))
    print(f"Confusion matrix: {test_metrics['confusion_matrix']}")

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": best, "model_name": best_name, "features": FEATURE_NAMES}, MODEL_PATH)

    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
    METRICS_PATH.write_text(
        json.dumps(
            {
                "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "best_model": best_name,
                "cross_validation": comparison.round(4).to_dict(orient="records"),
                "test": {k: (round(v, 4) if isinstance(v, float) else v) for k, v in test_metrics.items()},
                "top_features": top_features,
            },
            indent=2,
        )
    )
    print(f"\nSaved model to {MODEL_PATH.relative_to(ROOT)} and metrics to {METRICS_PATH.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
