"""Load the Wisconsin Diagnostic Breast Cancer dataset and split it.

The dataset ships with scikit-learn, so no download is needed.
In the original dataset 0 = malignant and 1 = benign. We flip it so that
1 = malignant, because malignant is the class we care about catching
(it becomes the "positive" class for recall, precision and ROC-AUC).
"""

from __future__ import annotations

import re

import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

RANDOM_STATE = 42
TEST_SIZE = 0.2


def to_snake(name: str) -> str:
    """'mean concave points' -> 'mean_concave_points' (used as API field names)."""
    return re.sub(r"\s+", "_", name.strip().lower())


def load_dataset() -> tuple[pd.DataFrame, pd.Series]:
    """Return features X (30 numeric columns, snake_case names) and target y (1 = malignant)."""
    raw = load_breast_cancer(as_frame=True)
    X = raw.data.copy()
    X.columns = [to_snake(c) for c in X.columns]
    y = (1 - raw.target).rename("malignant")  # flip: 1 = malignant, 0 = benign
    return X, y


FEATURE_NAMES: list[str] = list(load_dataset()[0].columns)


def split(X: pd.DataFrame, y: pd.Series):
    """Stratified 80/20 split so both sets keep the same malignant/benign ratio."""
    return train_test_split(
        X, y, test_size=TEST_SIZE, stratify=y, random_state=RANDOM_STATE
    )
