"""API tests. They train a small model first if none is saved yet."""

import pytest
from fastapi.testclient import TestClient

from api.main import MODEL_PATH, app
from bcd.data import load_dataset


@pytest.fixture(scope="module")
def client():
    if not MODEL_PATH.exists():
        from bcd import train

        train.main()
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="module")
def samples():
    X, y = load_dataset()
    malignant = X[y == 1].iloc[0].to_dict()
    benign = X[y == 0].iloc[0].to_dict()
    return malignant, benign


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "model_loaded": True}


def test_model_info(client):
    body = client.get("/model-info").json()
    assert body["n_features"] == 30
    assert body["metrics"]["test"]["roc_auc"] > 0.95


def test_predict_known_cases(client, samples):
    malignant, benign = samples
    r1 = client.post("/predict", json=malignant).json()
    r2 = client.post("/predict", json=benign).json()
    assert r1["diagnosis"] == "malignant" and r1["malignant_probability"] > 0.5
    assert r2["diagnosis"] == "benign" and r2["malignant_probability"] < 0.5


def test_predict_rejects_missing_feature(client, samples):
    bad = dict(samples[0])
    bad.pop("mean_radius")
    assert client.post("/predict", json=bad).status_code == 422


def test_predict_rejects_negative_value(client, samples):
    bad = dict(samples[0], mean_radius=-1)
    assert client.post("/predict", json=bad).status_code == 422


def test_batch(client, samples):
    r = client.post("/predict/batch", json={"samples": list(samples)})
    assert r.status_code == 200
    assert [p["diagnosis"] for p in r.json()] == ["malignant", "benign"]
