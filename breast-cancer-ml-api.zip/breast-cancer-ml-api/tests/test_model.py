"""Tests for data loading and the training pipeline."""

from bcd.data import FEATURE_NAMES, load_dataset, split
from bcd.train import candidate_models, evaluate


def test_dataset_shape_and_labels():
    X, y = load_dataset()
    assert X.shape == (569, 30)
    assert set(y.unique()) == {0, 1}
    assert int(y.sum()) == 212  # 212 malignant, 357 benign
    assert list(X.columns) == FEATURE_NAMES
    assert "mean_concave_points" in FEATURE_NAMES


def test_split_is_stratified():
    X, y = load_dataset()
    X_train, X_test, y_train, y_test = split(X, y)
    assert len(X_test) == 114
    assert abs(y_train.mean() - y_test.mean()) < 0.02


def test_logistic_regression_beats_baseline():
    X, y = load_dataset()
    X_train, X_test, y_train, y_test = split(X, y)
    model = candidate_models()["logistic_regression"].fit(X_train, y_train)
    metrics = evaluate(model, X_test, y_test)
    assert metrics["roc_auc"] > 0.95
    assert metrics["recall"] > 0.9
